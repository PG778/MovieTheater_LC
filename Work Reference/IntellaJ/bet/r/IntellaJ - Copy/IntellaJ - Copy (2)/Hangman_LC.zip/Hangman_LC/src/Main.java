import java.lang.reflect.Array;
import java.util.*;
/*
Lucas Castillo
Hangman Like Game
 */
public class Main {
    public static void main(String[] args) {
        // The next 3 lines of code initialize the scanner, then askk the user to enter a phrase for someone to guess, and stores it
        // to a String variale in all upper case letters
        Scanner input = new Scanner(System.in);
        System.out.println("Player, Enter a Phrase for your opponent to guess: ");
        String phrase = input.nextLine().toUpperCase();
        // converts the user's entered string to a Char Array
        /*
        This wasa my first time really using char arrays and variables, made it alot easier
         */
        char[] phraseArr = phrase.toCharArray();
        // Creates a new array for the astricts, but also te guessed letters by user.
        char[] guessedLetters = new char[phraseArr.length];
        //This loop sets spaces to stay, but all the letters to *
        for (int i = 0; i < guessedLetters.length;i++){
            if(phraseArr[i] == ' '  ){
                guessedLetters[i] = ' ';

            }else{
                guessedLetters[i] = '*';
            }
        }

        boolean wordGuessed = false;
        // while loop to run when the word is not yet guessed
        while(!wordGuessed){
            // prints the phrase to guess
            System.out.println(guessedLetters);
            // asks the user to input a letter to guess
            System.out.println("Enter A Letter To Guess: ");
            // saves guess to a char variable in uppercase form
            char Guess = input.nextLine().toUpperCase().charAt(0);

            boolean found = false;
            // this for loop checks to see if the guessed letter corresponds with any of te remaining letters in the phrase array
            // if the guess does, found becomes true and the letter guessed becomes revealed
            for(int i = 0; i < phraseArr.length;i++){
                if(phraseArr[i] == Guess) {
                    guessedLetters[i] = Guess;
                    found = true;
                }
            }
            // will print out corresponding essaes is user is right or wrong
            if(found == true){
                System.out.println("Good Job The Letter " + Guess + " was correct");
            }else{
                System.out.println("Wrong The Letter " + Guess + " was not in the phrase");
            }
            // this checks if the whole phrase has been guessed;
            for (char guessedLetter : guessedLetters) {
                if (guessedLetter == '*') {
                    wordGuessed = false;
                    break;
                } else {
                    wordGuessed = true;
                }
            }

        }


        System.out.println("Congrats You won! The Whole Phrase Was " + phrase);


    }
}