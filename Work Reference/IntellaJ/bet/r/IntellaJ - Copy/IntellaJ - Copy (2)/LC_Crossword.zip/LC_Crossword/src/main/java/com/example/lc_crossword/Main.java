package com.example.lc_crossword;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        // Board
        boolean[][] puzzleArea = {
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false},
                {true, true, true, true, true, true, true, true, true},
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false, false}
        };
        // all of the main content to run. This is where it broke.
        ArrayList<Clue> clues = new ArrayList<Clue>();
        // Createz the crossword object and allows it to be used.
        Crossword crossword = new Crossword(9, 9,  clues);

        //File reader to read the file, was working seperatly
        FileHandler file = new FileHandler();
        clues = file.readClues();
        for (Clue ye : clues) {
            System.out.println(ye);
        }
        // scanner runs through inut
        Scanner scanner = new Scanner(System.in);


        crossword.display();
    }
}








