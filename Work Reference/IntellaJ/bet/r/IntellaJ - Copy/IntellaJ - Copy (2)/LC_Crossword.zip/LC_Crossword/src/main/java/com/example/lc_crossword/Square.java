package com.example.lc_crossword;

public class Square {

        private char contents;

        public Square() {
            contents = '-';
        }

        public char getContents() {
            return contents;
        }

        public void setContents(char contents) {
            this.contents = contents;
        }
    }

