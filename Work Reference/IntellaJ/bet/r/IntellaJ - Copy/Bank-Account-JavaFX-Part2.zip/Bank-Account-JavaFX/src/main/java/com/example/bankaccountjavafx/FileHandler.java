/*



package com.example.bankaccountjavafx;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;

public class FileHandler {
    String username;
    String Password;
    PrintWriter file = new PrintWriter("Name.txt");
    Scanner keyboard = new Scanner(System.in);

    private int String;
    ArrayList  trans =new ArrayList(String);
    Scanner fileRead = new Scanner("Name.txt");
    public FileHandler(String _un, String _Ps) throws FileNotFoundException {
        username = _un;
        Password = _Ps;
    }

    public String createUser(String name, String pass){

        return name;
    }
    public String retrieveUser(){
        return username + Password;
        //user at that index
    }

    public void edituser(){
        Scanner change = new Scanner(System.in);
        if(createUser(username, Password)){
            System.out.println("Edit name");
            username = change.nextLine();
            System.out.println("Edit password");
            Password = change.nextLine();
        }
    }
    public void writeTransactions(){
        // idk how to do this but write all transations to a new file
    }

    public void getTransactions(){
        // get all lines fromm the file with the transactions and write them out.
    }







}

*/
/*
 This is what i did at first, it didnt work so i had to restart. Keeping ere for reference if i need it

 */
