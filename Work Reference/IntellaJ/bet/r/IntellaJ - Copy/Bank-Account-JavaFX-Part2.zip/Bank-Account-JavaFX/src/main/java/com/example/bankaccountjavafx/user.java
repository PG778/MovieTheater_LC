package com.example.bankaccountjavafx;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class user {

        private String username, password;

        public user(String username, String password){
            this.username = username;
            this.password = password;
        }


        String getUsername(){
            return username;
        }
        String getPassword(){
            return password;
        }

        public void setUsername(String username){
            this.username = username;
        }
        public void setPassword(String password){
            this.password = password;
        }

        void logOut(String username, String newName, double currentBalance, String dest) {

            Utils.updateBalance(username, currentBalance, dest);
            Utils.updateUser(username, newName, password, dest);
        }






}
