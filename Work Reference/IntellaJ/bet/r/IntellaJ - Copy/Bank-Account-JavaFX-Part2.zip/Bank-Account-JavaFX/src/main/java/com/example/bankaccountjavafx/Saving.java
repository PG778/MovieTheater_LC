package com.example.bankaccountjavafx;

public class Saving extends Holder{
    public Saving(double b, double sF, double oF, double tA, boolean iA, double mB, double d, double w) {
        super(b, sF, oF, tA, iA, mB, d, w);


    }


    private double getServiceFees(){
        return serviceFees;
    }

    private double withdraw(double withdraw){
        balance = balance - withdraw;
        addAccountAct();
        super.isTrue();
        return balance;
    }



}
