package com.example.bankaccountjavafx;

public class Holder
{

    double balance,serviceFees,overdraftFee,minBal,depo,with;
    double intrest;
    double transferAmount;
    boolean isAvail;

    public Holder(double b, double sF, double oF, double tA,boolean iA,double mB,double d, double w){
        balance = b;
        serviceFees = sF;
        overdraftFee = oF;
        intrest = 5.0;
        transferAmount = tA;
        isAvail = iA;
        minBal = mB;
        depo = d;
        with = w;
    }

    public void addAccountAct(){
        // every time a transactin is done add one to this
        transferAmount = transferAmount + 1;
    }
    static void setBalance(double bal){
        balance = balance + bal;

    }
    public void isTrue(){
        if (balance < 0.0){
            isAvail = false;
        }else{
            isAvail = true;
        }

    }
    private double chargeMonthlyIntrest(){
        return balance * intrest;
    }
    private double serviceFees(){
        for(int i = 0; i == 30;i++){
            if (transferAmount >= 3 && transferAmount < 6){
                return balance - 0.5;

            } else if (transferAmount >=6) {
                return balance - 1.0;
            }
        }
        return balance;
    }

    private double getBalance(){
        return balance;
    }


    private void setTransferAmount(double trans){
        transferAmount = trans;
    }
    private String chargeOverdraft(){
        if(isAvail == false){
            balance *= 0.5;
            minBal = balance;
            System.out.println("Your account is deactivated until you add at least $" + minBal + " and you hae been charged a fee");

        }
        return "";
    }

    private double Deposite(double dep){
       while(isAvail = false){
           balance = balance + depo;
           if (balance >= 0.0){
               isAvail = true;
           }else {
               System.out.println(" You must Deposite more for your account to become active, current balance is: $" + getBalance());

           }


       }
        return getBalance();
    }










}
