package com.example.bankaccountjavafx;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Utils extends Holder {


    public Utils(double b, double sF, double oF, double tA, boolean iA, double mB, double d, double w) {
        super(b, sF, oF, tA, iA, mB, d, w);
    }

    public void updateBalance(String username, double currentBalance, String destination){
        Holder.setBalance(currentBalance);
    }

    static void addUser(String name, String password) throws IOException {

        try (FileWriter fw = new FileWriter("src/main/java/com/example/bankaccountjavafx/checking.txt", true);
             PrintWriter PW = new PrintWriter(fw);
             PrintWriter pw = new PrintWriter(PW);
             FileWriter fw2 = new FileWriter("src/main/java/com/example/bankaccountjavafx/savings.txt", true);
             PrintWriter PW2 = new PrintWriter(fw2);
             PrintWriter pw2 = new PrintWriter(PW2);) {

            pw.println(name + "," + password + "," + "0.00" + ",");
            pw2.println(name + "," + password + "," + "0.00" + ",");
            pw.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
