package com.example.lc_crossword;

public class Clue{
    //Variable init
    public final int row;
    public final int col;
    public final boolean isHorizontal;
    public final int number;
    public final String answer;
    public final String clueText;


    // Constructor to set the variables to the proper values.
    public Clue(int row, int col, boolean isHorizontal, int number, String answer, String clueText) {
        this.row = row;
        this.col = col;
        this.isHorizontal = isHorizontal;
        this.number = number;
        this.answer = answer;
        this.clueText = clueText;
    }


    // This method allows the code to get rows, or how many wide the array is
    public int getRow() {
        return row;
    }

    // This method allows the code to get Columns, or how many Long the array is
    public int getCol() {
        return col;
    }
    // This method allows the code to get and set a variable to posotive if the clue isowizontal, up and down.
    public boolean isHorizontal() {
        return isHorizontal;
    }
    // this methos gets the number of te clue and coreesponds it with the row yha it is in.
    public int getNumber() {
        return number;
    }
    // ets the answer that corresponds with the number and thing in the file
    public String getAnswer() {
        return answer;
    }
    // gets the clue text that corresponds with the  numer and placement on th board
    public String getClueText() {
        return clueText;
    }
    public String toString(){
        return getRow() + " " + getCol() + " " +  isHorizontal() + " " +  getNumber() + " " +  getAnswer() + " " +  getClueText();
    }
}

