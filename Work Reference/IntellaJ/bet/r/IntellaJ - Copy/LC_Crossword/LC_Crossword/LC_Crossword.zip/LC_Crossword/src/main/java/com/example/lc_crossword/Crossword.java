package com.example.lc_crossword;

import java.util.ArrayList;

public class Crossword {
    // Initializeable variable for teh grid
    private final Square[][] grid;
    // clues arraylist
    private ArrayList<Clue> clues;

    //this is the construcer for this class and allows eerything to be used
    public Crossword(int numRows, int numCols, ArrayList<Clue> clues) {
        grid = new Square[numRows][numCols];
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                grid[i][j] = new Square();
            }
        }
        this.clues = clues;
        for (Clue clue : clues) {
            int row = clue.getRow();
            int col = clue.getCol();
            int length = clue.getNumber();
            boolean isHorizontal = clue.isHorizontal();
            for (int i = 0; i < length; i++) {
                if (isHorizontal) {
                    Square[row][col + i].setIsWhite(true);
                    if (i == 0 || grid[row][col + i - 1].isBlack()) {
                        Square[row][col + i].setNumber(clue.getNumber());
                    }
                } else {
                    grid[row + i][col].setIsWhite(true);
                    if (i == 0 || Square[row + i - 1][col].isBlack()) {
                        Square[row + i][col].setNumber(clue.getNumber());
                    }
                }
            }
        }

    }
    // This method displays the grid before, and after an update is made.
    public void display() {
        for (int row = 0; row < grid.length; row++) {
            for (int col = 0; col < grid[row].length; col++) {
                if (isBlackSquare(row, col)) {
                    System.out.print("*");
                } else {
                    boolean isStartOfHorizontal = isStartOfHorizontalClue(row, col);
                    boolean isStartOfVertical = isStartOfVerticalClue(row, col);
                    if (isStartOfHorizontal || isStartOfVertical) {
                        int clueNumber = getClueNumber(row, col);
                        System.out.print(clueNumber);
                    } else {
                        System.out.print(".");
                    }
                }
                System.out.print(" ");
            }
            System.out.println();
        }
    }
    // Sets a boolean value to true if there is a black square in the ggrid at index i and j
    private boolean isBlackSquare(int row, int col) {
        return grid[row][col] == null;
    }
    // Menthod to place clue horizontal
    private boolean isStartOfHorizontalClue(int row, int col) {
        return (col == 0 || isBlackSquare(row, col-1)) && col < grid[row].length - 1 && !isBlackSquare(row, col+1);
    }
    // Menthod to place clue Verticle
    private boolean isStartOfVerticalClue(int row, int col) {
        return (row == 0 || isBlackSquare(row-1, col)) && row < grid.length - 1 && !isBlackSquare(row+1, col);
    }
    // Gets the clue number that is due next
    private int getClueNumber(int row, int col) {
        int count = 1;
        while (col > 0 && !isBlackSquare(row, col-1)) {
            col--;
            count++;
        }
        while (row > 0 && !isBlackSquare(row-1, col)) {
            row--;
            count++;
        }
        return count;
    }
}

