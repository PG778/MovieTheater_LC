package com.example.lc_crossword;

import java.util.ArrayList;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class FileHandler {
    // Variable Init
    private static String fileName;
    public static ArrayList<Clue> clues;
    // constructor sets the file name to my text fiecontaining all of my information in it
    public FileHandler() {

        FileHandler.fileName = "src/text";
        clues = new ArrayList<Clue>();
    }
// Method just runs through spliiting up all of the information to meet the requirements.
    public static ArrayList<Clue> readClues() throws FileNotFoundException {
        File file = new File("src/text");
        Scanner scanner = new Scanner(file);

        while (scanner.hasNext()) {
            String line = scanner.nextLine();
            String[] parts = line.split(":");

            int row = Integer.parseInt(parts[0]);
            int col = Integer.parseInt(parts[1]);
            boolean orientation = Boolean.parseBoolean(parts[2]);
            int number = Integer.parseInt(parts[3]);
            String answer = parts[4];
            String clue = parts[5];

            clues.add(new Clue(row, col, orientation, number, answer, clue));
        }

        scanner.close();
        return clues;
    }
}

