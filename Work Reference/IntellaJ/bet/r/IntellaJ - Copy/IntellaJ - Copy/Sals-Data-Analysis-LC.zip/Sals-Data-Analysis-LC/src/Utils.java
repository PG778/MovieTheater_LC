public class Utils {

    private int weeks, highSale, lowSale;
    double TotalSalesWeekly, dailySales;

}
