package com.example.factoryworkers_lc;

public class ShiftSpervisor extends Employee{
    //this variable is the annual bonus
    private double monthlyBonus;
    private double trainingHours = 10.0;
    private double trainingHoursCompleted;
    private double wage;

    private boolean trainingDone = false;

    public ShiftSpervisor(String _name, String _number, String _hire, double _monthly, double _trainingHoursCommpleted, double _wage) {
        super(_name, _number, _hire);
        monthlyBonus = _monthly;
        trainingHoursCompleted = _trainingHoursCommpleted;
        wage = _wage;
    }




    public void setMonthlyBonus(double bonus){
        monthlyBonus = bonus;
    }
    public double getMonthlyBonus(){
        return monthlyBonus;
    }

    public void setTrainingHoursCompleted(double completed){
        trainingHoursCompleted = completed;
    }
    public String isTrainingDone(){
        String amount = null;
        double remaining;
        if(trainingHoursCompleted >= trainingHours){
            amount = "You have completed training!";
            trainingDone = true;
        } else if (trainingHoursCompleted < trainingHours) {
            amount = "You have not finished training.";
            trainingDone = false;


        }

        return amount;
    }
    public void setWage(double salary){
        wage = salary;
    }
    public double getWage(){
        return wage;
    }

    public String toString(){



        return "Hello " + super.getName() + ", " + ", your employee number is " + super.getNumber() + ", and your wage/salary is " + getWage() + "\n. Your monthly bonus as a supervisor is " + getMonthlyBonus() + "\n  " + isTrainingDone() + " You met the qoota, enjoy your bonus as you requested.";
    }





}
