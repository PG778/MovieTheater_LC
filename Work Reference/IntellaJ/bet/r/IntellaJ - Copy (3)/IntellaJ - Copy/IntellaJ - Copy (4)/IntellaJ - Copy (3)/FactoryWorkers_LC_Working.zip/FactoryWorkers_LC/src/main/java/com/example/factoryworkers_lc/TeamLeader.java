package com.example.factoryworkers_lc;

public class TeamLeader extends ProductionWorker{
    private double monthlyBonus;
    private double trainingHours = 10.0;
    private double trainingHoursCompleted;

    private boolean trainingDone = false;

    public TeamLeader(String _name, String _number, String _hire, int _Shift, double _Wage, double _monthly,double _trainingHoursCommpleted) {
        super(_name, _number, _hire, _Shift, _Wage);
        monthlyBonus = _monthly;
        trainingHoursCompleted = _trainingHoursCommpleted;

    }




    public void setMonthlyBonus(double bonus){
        monthlyBonus = bonus;
    }
    public double getMonthlyBonus(){
        return monthlyBonus;
    }

    public void setTrainingHoursCompleted(double completed){
        trainingHoursCompleted = completed;
    }
    public String isTrainingDone(){
        String amount = null;
        double remaining;
        if(trainingHoursCompleted >= trainingHours){
            amount = "You have completed training!";
            trainingDone = true;
        } else if (trainingHoursCompleted < trainingHours) {
            amount = "You have not finished training.";
            trainingDone = false;


        }

        return amount;
    }

    public String toString(){
        String shiftStr = null;

        if(super.getShift() == 1){
            shiftStr = "You are working the Day Shift";
        } else if (super.getShift() == 2) {
            shiftStr = "You are working the Night Shift";
        }


        return "Hello " + super.getName() + ", " + shiftStr + ", your employee number is " + super.getNumber() + ", and your wage is " + getWage() + "\n. Your yearly bonus as a manager is " + getMonthlyBonus() + "\n  " + isTrainingDone()
                + "\n Your annual salary is " + monthlyBonus *2;
    }




}
