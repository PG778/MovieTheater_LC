package com.example.factoryworkers_lc;

public class ProductionWorker extends Employee{
    private int Shift;
    private double wage;
    public ProductionWorker(String _name, String _number, String _hire, int _Shift, double _Wage) {
        super(_name, _number, _hire);
        Shift = _Shift;
        wage = _Wage;
    }

    public void setShift(int shift){
      Shift = shift;
    }
    public int getShift(){
        return Shift;
    }
    public void setWage(double pay){
        wage = pay;
    }
    public double getWage(){
        return wage;
    }

    public String toString(){
        String shiftStr = null;
        if(Shift == 1){
            shiftStr = "You are working the Day Shift";
        } else if (Shift == 2) {
            shiftStr = "You are working the Night Shift";
        }

        return "Hello " + super.getName() + ", " + shiftStr + ", your employee number is " + super.getNumber() + ", and your wage is " + getWage();
    }








}


