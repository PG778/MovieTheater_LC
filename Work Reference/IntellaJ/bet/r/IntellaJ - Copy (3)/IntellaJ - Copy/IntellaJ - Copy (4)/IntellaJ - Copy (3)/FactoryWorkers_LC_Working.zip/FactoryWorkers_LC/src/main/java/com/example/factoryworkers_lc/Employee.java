package com.example.factoryworkers_lc;

public class Employee {
    private String name;
    private String number;
    private String hire;

    public Employee(String _name, String _number, String _hire){
        name = _name;
        number = _number;
        hire = _hire;

    }

    public void setName(String _name){
        name = _name;
    }

    public String getName(){
        return name;
    }

    public void setNumber(String num){
        number = num;
    }
    public String getNumber(){
        return number;
    }
    public void setHireDate(String hired){
        hire = hired;
    }
    public String getHire(){
        return hire;
    }






}
