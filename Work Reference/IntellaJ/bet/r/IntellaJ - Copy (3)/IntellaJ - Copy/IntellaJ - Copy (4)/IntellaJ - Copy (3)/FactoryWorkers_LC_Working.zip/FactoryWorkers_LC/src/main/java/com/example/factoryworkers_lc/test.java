package com.example.factoryworkers_lc;

import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
/* Test For First case
        System.out.println("Enter your name: ");
        String name = input.nextLine();

        System.out.println("Enter your employee number: ");
        String number = input.nextLine();

        System.out.println("Enter your Hire Date: ");
        String hire = input.nextLine();

        System.out.println("Enter Your next shift in the form of a number: ");
        int shift = input.nextInt();

        System.out.println("Enter your desired wage for this shift: ");
        double wage = input.nextDouble();


        ProductionWorker one = new ProductionWorker(name, number, hire, shift, wage);

        System.out.println(one);


        */
/*
        System.out.println("Enter your name: ");
        String name = input.nextLine();

        System.out.println("Enter your employee number: ");
        String number = input.nextLine();

        System.out.println("Enter your Hire Date: ");
        String hire = input.nextLine();

        System.out.println("Enter Your next shift in the form of a number: ");
        int shift = input.nextInt();

        System.out.println("Enter your desired wage for this shift: ");
        double wage = input.nextDouble();

        System.out.println("Enter the bonus: ");
        double bonus = input.nextDouble();

        System.out.println("Enter how many hours you have completed in training: ");
        double train = input.nextDouble();


        TeamLeader two = new TeamLeader(name, number, hire, shift, wage, bonus, train);

        System.out.println(two);

        */
        System.out.println("Enter your name: ");
        String name = input.nextLine();

        System.out.println("Enter your employee number: ");
        String number = input.nextLine();

        System.out.println("Enter your Hire Date: ");
        String hire = input.nextLine();



        System.out.println("Enter your salary as a supervisor: ");
        double wage = input.nextDouble();

        System.out.println("Enter the bonus: ");
        double bonus = input.nextDouble();

        System.out.println("Enter how many hours you have completed in training: ");
        double train = input.nextDouble();


        ShiftSpervisor two = new ShiftSpervisor(name, number, hire, bonus, train, wage);

        System.out.println(two);

    }


}



