package com.example.blanket;

import java.io.*;

public class FileUtils {
    private final static File file = new File("src/main/resources/Blankets.txt");

    public static void printInfoToFile(){
        try {
            PrintWriter pw = new PrintWriter(file);

            for (int i = 1; i <= 4; i++){
                for (int j = 1; j <= 3; j++){
                    for (int k = 1; k <= 3; k++){
                        Blanket blanket = new Blanket();
                        ElectricBlanket eBlanket = new ElectricBlanket();

                        eBlanket.setSize(i);
                        blanket.setSize(i);
                        eBlanket.setMaterial(j);
                        blanket.setMaterial(j);
                        eBlanket.setColor(k);
                        blanket.setColor(k);
                        eBlanket.setAutoOnOff(true);

                        pw.println(blanket);
                        pw.println(eBlanket);
                    }
                    pw.println();
                }
                pw.println();

                pw.println("\n");
            }

            pw.close();
        }

        catch (Exception e){
            System.out.println("Error");
        }
    }
}
