package com.example.blanket;

import java.io.File;
import java.util.*;

/*
Lucas Castllo
Trevor St Amand
Purpose - Practice Problem - Inheritance
Allows the user to make a blanket of their choice. Prints the price and properties at the end, and prints the cost of all combinations
in a text file.
 */


public class Main {
    public static void main(String[] args) {
        FileUtils.printInfoToFile();
        Scanner input = new Scanner(System.in);
        Blanket blanket = new Blanket();
        ElectricBlanket eBlanket = new ElectricBlanket();

        while (true){
            System.out.println(blanket);

            System.out.println("Enter the desired size for your blanket: \n 1) Twin\n 2) Double\n 3) Queen\n 4) King ");
            int size = input.nextInt();
            blanket.setSize(size);

            System.out.println("What would you like the material to be? \n1) Cotton \n2) Wool \n3) Cashmere");
            int material = input.nextInt();
            blanket.setMaterial(material);

            System.out.println("What color would you like? \n1) White \n2) Tan \n3) Green ");
            int color = input.nextInt();
            blanket.setColor(color);

            System.out.println("Enter continue to make electric blanket");

            input.nextLine();

            String cont = input.nextLine();

            if (cont.equalsIgnoreCase("Continue")){
                break;
            }
        }


        while(true) {
            System.out.println(eBlanket);

            System.out.println("Enter the desired size for your blanket: \n 1) Twin\n 2) Double\n 3) Queen\n 4) King ");
            int size = input.nextInt();
            blanket.setSize(size);

            System.out.println("What would you like the material to be? \n1) Cotton \n2) Wool \n3) Cashmere");
            int material = input.nextInt();
            blanket.setMaterial(material);

            System.out.println("What color would you like? \n1) White \n2) Tan \n3) Green ");
            int color = input.nextInt();
            blanket.setColor(color);

            System.out.println("Select a heat setting 1-5 inclusive: ");
            int heat = input.nextInt();
            eBlanket.setHeatSetting(heat);

            System.out.println("Does this Electric blanket have an auto shut off feature(TRUE or FALSE)?");
            boolean auto = input.nextBoolean();
            eBlanket.setAutoOnOff(auto);

            input.nextLine();

            System.out.println("Enter exit to exit");
            String exit = input.nextLine();
            if (exit.equalsIgnoreCase("exit")){
                break;
            }
        }

        System.out.println("Normal blanket");
        System.out.println(blanket);

        System.out.println("\nElectric blanket");
        System.out.println(eBlanket);
    }
}
