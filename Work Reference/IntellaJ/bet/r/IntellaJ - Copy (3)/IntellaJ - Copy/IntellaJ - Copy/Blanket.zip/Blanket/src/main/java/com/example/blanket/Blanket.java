package com.example.blanket;

public class Blanket {
    private String size, material, color;
    protected double price, matPrice = 0, sizePrice = 0;

    public Blanket() {
        size = "Twin";
        color = "White";
        material = "Cotton";
        price = 30.00;
    }

    public void setSize(int sizeChoice) {
        price -= sizePrice;
        switch (sizeChoice) {
            case 2 -> {
                size = "Double";
                price += 10;
                sizePrice = 10;
            }

            case 3 -> {
                size = "Queen";
                price += 25;
                sizePrice = 25;
            }

            case 4 -> {
                size = "King";
                price += 40;
                sizePrice = 40;
            }

            default -> {
                size = "Twin";
                sizePrice = 0;
            }
        }
    }

    public void setMaterial(int matChoice) {
        price -= matPrice;
        switch (matChoice) {
            case 2 -> {
                material = "Wool";
                price += 25;
                matPrice = 25;
            }

            case 3 -> {
                material = "Cashmere";
                price += 40;
                matPrice = 40;
            }

            default -> {
                material = "Cotton";
                matPrice = 0;
            }
        }
    }

    public void setColor(int colorChoice) {
        switch (colorChoice) {
            case 2 -> color = "Tan";

            case 3 -> color = "Green";

            default -> color = "White";
        }
    }

    public double getSizePrice(){return sizePrice;}

    public double getMatPrice(){return matPrice;}


    @Override
    public String toString() {
        return "Size: " + size + " -- Material: " + material + " -- Color: " + color + " -- Price: " + price;
    }
}
