package com.example.blanket;

public class ElectricBlanket extends Blanket{
    // Variables
    int heatSetting;
    boolean autoOnOff;
//constructor for ElectricBlankey
    public ElectricBlanket(){
        heatSetting = 1;
        autoOnOff = false;
    }

    // Sets the heat setting variable to the desired value
    public void setHeatSetting(int _heatSetting){
        if (_heatSetting >=1 && _heatSetting <=5){
            heatSetting = _heatSetting;
        }else{
            heatSetting = 1;
        }

    }
    // gets the heat setting variable
    public int getHeatSetting(){
        return heatSetting;
    }


    // sets the Auto shut off featur variable to on of off based on user input, also adds the tax for having this settng true
    public void setAutoOnOff(boolean autoOnOff){
        if (!(this.autoOnOff == autoOnOff)){
            if (autoOnOff){
                price += 5.75;
            }

            else{
                price -= 5.75;
            }

            this.autoOnOff = autoOnOff;
        }
    }
    // returns the value of the auto on off feature.
    public boolean getAutoOnOff(){
        return autoOnOff;
    }

    // The to string overrides the parent class if it is called to do so in main or file handling.
    @Override
    public String toString(){
        return super.toString() + " Heat Setting: " + getHeatSetting() + " Shutoff Feature: " + getAutoOnOff();
    }



}
