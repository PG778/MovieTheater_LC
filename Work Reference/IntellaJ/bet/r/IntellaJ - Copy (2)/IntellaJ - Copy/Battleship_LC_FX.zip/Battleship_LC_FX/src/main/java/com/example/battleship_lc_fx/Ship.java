package com.example.battleship_lc_fx;

public class Ship {

    private String name;
    private int size,hits;

    public Ship(String name, int size, int health){
        this.name = name;
        this.size = size;
        hits = 0;
    }

    public void setName(){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public void setSize(){
        this.size = size;
    }
    public int getSize(){
        return  size;
    }
    public int getHits(){
        return hits;
    }
    public void setHits(){
        this.hits = hits;
    }
    public boolean isAlive(){
        return hits==size;
    }
}
