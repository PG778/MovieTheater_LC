package com.example.battleship_lc_fx;


import java.util.*;

public class BattleShips {

    final static int y_HEADING_OFFSET = 64;
    static Cell[][] boardCells;
    public static int playerShips;
    public static int computerShips;


    public static void main(String[] args){
        Cell cell = new Cell();

        // Create the ocean map
        cell.createGameBoard();


        //Deploy player’s ships
        cell.deployPlayerShips();

        //Deploy computer's ships
        cell.deployComputerShips();

        // Battle method call
        do {
            cell.Battle();
        }while(BattleShips.playerShips != 0 && BattleShips.computerShips != 0);

        // Game over when one player doesnt have any ships left
        cell.gameOver();
    }


}