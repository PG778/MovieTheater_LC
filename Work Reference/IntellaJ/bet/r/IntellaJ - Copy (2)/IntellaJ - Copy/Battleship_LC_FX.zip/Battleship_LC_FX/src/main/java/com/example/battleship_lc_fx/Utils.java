package com.example.battleship_lc_fx;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Utils {
    public static Ship[] importShipStats(String filePath) {
        Ship[] ships = null;
        try {
            File file = new File("ShipStats");
            Scanner scanner = new Scanner(file);
            int numShips = scanner.nextInt();
            ships = new Ship[numShips];
            for (int i = 0; i < numShips; i++) {
                String name = scanner.next();
                int length = scanner.nextInt();
                int health = scanner.nextInt();
                ships[i] = new Ship(name, length, health);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return ships;
    }
}
