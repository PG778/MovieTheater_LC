package com.example.battleship_lc_fx;

public class Player {
    private String name;
    private Ship[] ships;

    public Player(String name, Ship[] ships){
        this.name = name;
        this.ships = ships;
    }
    public String getName(){
        return name;
    }
    public Ship[] getShips(){
        return ships;
    }
}
