package com.example.battleship_lc_fx;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Cell {

    String cellText;
    private boolean hasShip;
    private boolean isHit;

    private int x, y;

    static int Rows = 10;
    static int col = 10;

    public static String[][] grid = new String[Rows][col];
    public static int[][] missedGuesses = new int[Rows][col];


    public static char[] alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};



    public Cell() {


        cellText = "-";
        hasShip = false;
        isHit = false;

    }


    public boolean hasShip() {
        return hasShip;
    }

    public void setHasShip(boolean hasShip) {
        this.hasShip = hasShip;
    }

    public boolean isHit() {
        return isHit;
    }

    public void setHit(boolean hit) {
        isHit = hit;
    }



    public static void createGameBoard(){
        //First section of GameBoard, prints row names
        System.out.print("-");
        for(int i = 0; i < col; i++)
            System.out.print(i + " ");
        System.out.println();

        //Main Secton of the board, this is the print for the ddashs (Place holders)
        for(int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                grid[i][j] = "- ";
                if (j == 0)
                    System.out.print(alphabet[i] + grid[i][j]);

                else
                    System.out.print(grid[i][j]);
            }
            System.out.println();
        }



    }
    public static void printGameBoard(){
        System.out.println();
        //GameBoard beginning
        System.out.print("  ");
        for(int i = 0; i < col; i++)
            System.out.print(i);
        System.out.println();

        //This doesnt create anything but this prints it (the main board)
        for(int x = 0; x < grid.length; x++) {
            System.out.print(x + "|");

            for (int y = 0; y < grid[x].length; y++){
                System.out.print(grid[x][y]);
            }

            System.out.println("|" + x);
        }


        System.out.print("  ");
        for(int i = 0; i < col; i++)
            System.out.print(i);
        System.out.println();
    }


    // this just runs the game, will stop when the player or enemny shis hizero, this is determined by while loop in main.

    public static void Battle(){
        // this just runs the game, will stop when the player or enemny shis hizero, this is determined by while loop in main.
        playerTurn();
        computerTurn();

        printGameBoard();

        System.out.println();
        System.out.println("Your ships: " + BattleShips.playerShips + " | Rand ships: " + BattleShips.computerShips);
        System.out.println();
    }

    //this method just asks user to input a location, letter and number to place ship
    public static void deployPlayerShips(){
        Scanner input = new Scanner(System.in);

        System.out.println("\nPlace your ships:");
        //Deploying five ships for player
        BattleShips.playerShips = 5;
        for (int i = 1; i <= BattleShips.playerShips; ) {
            System.out.print("Enter X coordinate for your " + i + " ship: ");
            int x = input.nextInt();
            System.out.print("Enter Y coordinate for your " + i + " ship: ");
            int y = input.nextInt();

            if((x >= 0 && x < Rows) && (y >= 0 && y < col) && (grid[x][y] == "-"))
            {
                grid[x][y] =   "s";
                i++;
            }
            else if((x >= 0 && x < Rows) && (y >= 0 && y < col) && grid[x][y] == "s")
                System.out.println("You can't place two or more ships on the same location");
            else if((x < 0 || x >= Rows) || (y < 0 || y >= col))
                System.out.println("You can't place ships outside the " + Rows + " by " + col + " grid");
        }
        printGameBoard();
    }

    //this method just places emeny ships with a random number between ranges

    public static void deployComputerShips(){
        System.out.println("\nRand is deploying ships");
        //Deploying five ships for computer
        BattleShips.computerShips = 5;
        for (int i = 1; i <= BattleShips.computerShips; ) {
            int x = (int)(Math.random() * 10);
            int y = (int)(Math.random() * 10);

            if((x >= 0 && x < Rows) && (y >= 0 && y < col) && (grid[x][y] == "-"))
            {
                grid[x][y] =   "s";
                System.out.println(i + ". ship Places");
                i++;
            }
        }
        printGameBoard();
    }
    //determines wos turn
    public static void playerTurn(){
        System.out.println("\nYOUR TURN");
        int x = -1, y = -1;
        do {
            Scanner input = new Scanner(System.in);
            System.out.print("Enter X coordinate: ");
            x = input.nextInt();
            System.out.print("Enter Y coordinate: ");
            y = input.nextInt();

            if ((x >= 0 && x < Rows) && (y >= 0 && y < col)) //valid guess
            {
                if (grid[x][y] == "x") //if Rand ship is already there; computer loses ship
                {
                    System.out.println("Boom! You sunk the ship!");
                    grid[x][y] = "x"; //Hit cell text
                    --BattleShips.computerShips;
                }
                else if (grid[x][y] == "x") {
                    System.out.println("Oh no, you sunk your own ship :(");
                    grid[x][y] = "x";
                    --BattleShips.playerShips;
                    ++BattleShips.computerShips;
                }
                else if (grid[x][y] == "0") {
                    System.out.println("Sorry, you missed");
                    grid[x][y] = "0";
                }
            }
            else if ((x < 0 || x >= Rows) || (y < 0 || y >= col))  //invalid guess
                System.out.println("You can't place ships outside the " + Rows + " by " + col + " grid");
        }while((x < 0 || x >= Rows) || (y < 0 || y >= col));  //keep re-prompting till valid guess
    }

    public static void computerTurn(){
        System.out.println("\nRand'S TURN");
        //Guess co-ordinates
        int x = -1, y = -1;
        do {
            x = (int)(Math.random() * 10);
            y = (int)(Math.random() * 10);

            if ((x >= 0 && x < Rows) && (y >= 0 && y < col)) //valid guess
            {
                if (grid[x][y] == "@") //if player ship is already there; player loses ship
                {
                    System.out.println("The Rand sunk one of your ships!");
                    grid[x][y] = "x";
                    --BattleShips.playerShips;
                    ++BattleShips.computerShips;
                }
                else if (grid[x][y] == "x") {
                    System.out.println("The Rand sunk one of its own ships");
                    grid[x][y] = "x";
                }
                else if (grid[x][y] == "o") {
                    System.out.println("Rand missed");
                    //Saving missed guesses for computer
                    if(missedGuesses[x][y] != 1)
                        missedGuesses[x][y] = 1;
                }
            }
        }while((x < 0 || x >= Rows) || (y < 0 || y >= col));  //keep re-prompting till valid guess
    }

    //runs when game ends
    public static void gameOver(){
        System.out.println("Your ships: " + BattleShips.playerShips + " | Rand ships: " + BattleShips.computerShips);
        if(BattleShips.playerShips > 0 && BattleShips.computerShips <= 0)
            System.out.println("Hooray! You won the battle :)");
        else
            System.out.println("Sorry, you lost the battle");
        System.out.println();
    }


}
