import java.lang.reflect.Array;
import java.lang.reflect.Array;
import java.util.Arrays;

public class Utils {
    int Nums[]= {0,0,0,0}  ;


    public Utils(){
        Nums = this.Nums;
    }

    public static int[] run(){
        return Nums;
    }

}
