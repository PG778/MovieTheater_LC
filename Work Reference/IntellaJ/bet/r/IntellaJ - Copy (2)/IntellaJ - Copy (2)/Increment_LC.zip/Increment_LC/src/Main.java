import java.util.Arrays;

import static jdk.internal.vm.ExtentLocalContainer.run;

public class Main {
    public static void main(String[] args) {
       Utils run = new Utils();

        int count = 0;
        int[] tempArray = Arrays.copyOf(Utils.run(), 4);
        for(int i = 0;i < Utils.run().length;i++){
            while (count < 9){
                // i wanted this to sett the element to cont up until it reaches 9
                tempArray.set(i,count);
                count++;
            }
            count = 0;
        }
    }


}